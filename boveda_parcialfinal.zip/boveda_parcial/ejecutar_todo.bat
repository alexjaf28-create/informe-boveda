@echo off
REM Compila y ejecuta todos los archivos de datos\ con ambas versiones.
cd /d "%~dp0"
if exist out rmdir /s /q out
mkdir out
if not exist salidas mkdir salidas
dir /s /b src\*.java > fuentes.tmp
javac -encoding UTF-8 -d out @fuentes.tmp
if errorlevel 1 exit /b 1
del fuentes.tmp
for %%f in (datos\*.txt) do (
  java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp out app.Main "%%f" > "salidas\%%~nf.salida.txt"
  echo %%~nf
)
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp out pruebas.CasosPrueba > salidas\casos_prueba.salida.txt
type salidas\casos_prueba.salida.txt
