# Bóveda de fichas — Parcial

Programa en Java construido sobre la plantilla del profesor (`plantilla-boveda`): se conservaron
sus clases, firmas y estructura de paquetes y se completaron todos los `TODO`.

| Versión | Paquete | Estructuras |
|---|---|---|
| Manual | `manual` | `ListaFichas`, `PilaSimbolos`, `ColaPistas` (propias, sobre `Nodo<T>`) |
| Biblioteca | `biblioteca` | `LinkedList`, `ArrayDeque` (como `Deque`), `Queue` de `java.util` |

## Estructura

```
src/
  dominio/      Ficha, TipoFicha                         (de la plantilla, sin cambios)
  app/          LectorFichas (paso 1), Main
  manual/       Nodo, ListaFichas, PilaSimbolos, ColaPistas, ValidadorManual
  biblioteca/   ValidadorBiblioteca
  pruebas/      CasosPrueba
datos/          archivos de entrada válidos e inválidos
salidas/        salida real de cada ejecución
```

## Compilar y ejecutar

Desde la carpeta que contiene `src`:

```
javac -encoding UTF-8 -d out $(find src -name "*.java")
java -cp out app.Main datos/ejemplo_valido.txt
java -cp out pruebas.CasosPrueba
```

En Windows (PowerShell) no existe `find`; compile así:

```
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src -Filter *.java).FullName
java -cp out app.Main datos/ejemplo_valido.txt
```

Segundo argumento opcional para una sola versión: `manual`, `biblioteca` o `ambas` (por defecto).
Si las tildes salen mal, agregue `-Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8` después de `java`.
`ejecutar_todo.sh` / `ejecutar_todo.bat` compilan y regeneran todas las salidas en `salidas/`.

Código de salida de `Main`: 0 válido, 1 error encontrado, 2 uso incorrecto, 3 las versiones no coinciden.

## Qué se completó de la plantilla

| Paso | Qué ocurre | Dónde |
|---|---|---|
| 1 | Lee y valida encabezado, 5 campos, tipo, valor, prioridad, instrucción, ids únicos y sintaxis de referencias. Guarda línea física y posición. | `LectorFichas.leer` |
| 2 | Inserta las fichas en la lista enlazada, muestra el recorrido y busca letras por id recorriendo la lista. | `ListaFichas.agregar/buscar/recorrido` |
| 3 | Apila cada apertura; ante un cierre compara con el tope y retira solo si corresponde; al final la pila debe quedar vacía. | `PilaSimbolos`, `ValidadorManual.validarDelimitadores` |
| 4 | Encola las PISTA en tres colas FIFO, una por prioridad. | `ColaPistas.encolar` |
| 5 | Atiende P1, luego P2 y P3. `ENCADENAR:id1:id2` revela `id1` y agrega `REVELAR:id2` al final de su misma cola. | `ColaPistas.desencolar`, `resolverPistas` |
| 6 | Ejecuta ambas versiones y compara mensaje / primer error y orden de eventos. | `Main.comparar` |

La traza registra consultas, inserciones, retiros, búsquedas y errores con las etiquetas
`[LECTURA] [LISTA] [PILA] [COLA] [BUSQUEDA] [MENSAJE] [ERROR]`. Un error detiene las fases siguientes
y conserva la traza producida hasta ese momento.

Decisiones donde el enunciado no precisa:

- **Apertura sobrante:** se informa al terminar el recorrido, indicando el símbolo que quedó en el tope.
- **Referencias:** la sintaxis se valida al leer; que la ficha exista, sea LETRA y no esté repetida se comprueba al atender la pista (paso 5), porque ahí ocurre la búsqueda en la lista.
- **Errores de lectura:** el lector lanza `IllegalArgumentException` (formato) o `IOException` (archivo); `Main` los informa y no ejecuta las fases posteriores, por eso esos casos no tienen comparación.
- **Letra repetida (manual):** se controla con una segunda `ListaFichas` de letras ya reveladas, para no usar colecciones de `java.util`.
- **Espacios:** se ignoran alrededor de cada campo. Línea física: el encabezado es la línea 1.
- `java.util` en la versión manual solo aparece en `List` (tipo de entrada que fija la plantilla) e `Iterator` (para recorrer `ListaFichas` sin exponer `Nodo`).

## Pruebas (carpeta `datos/`, resumen en `salidas/casos_prueba.salida.txt`)

| Archivo | Qué comprueba | Resultado esperado |
|---|---|---|
| `ejemplo_valido.txt` | Ejemplo del enunciado con ENCADENAR | `SOL` |
| `prueba_tres_prioridades.txt` | Pistas en P1, P2 y P3 con orden físico distinto | `SOL` |
| `prueba_fifo_misma_prioridad.txt` | Tres pistas de P2 (FIFO) | `SOL` |
| `prueba_encadenar_cola_con_pistas.txt` | ENCADENAR agrega una pista detrás de otra que sigue en la cola | `SOL` |
| `invalido_f05_cierre_incorrecto.txt` | F05 cierra con `)` y el tope es `[` | PILA, línea 6, F05 |
| `invalido_cierre_sin_apertura.txt` | Cierre con la pila vacía | PILA, línea 3, F02 |
| `invalido_apertura_sobrante.txt` | Queda un `(` sin cerrar | PILA, apertura sobrante |
| `invalido_id_repetido.txt` | F02 aparece dos veces | LECTURA, línea 4 |
| `invalido_linea_incompleta.txt` | Fila con 4 campos | LECTURA, línea 4 |
| `invalido_tipo.txt` | Tipo `NUMERO` | LECTURA, línea 3 |
| `invalido_valor.txt` | ABRE con `<` | LECTURA, línea 2 |
| `invalido_prioridad.txt` | Prioridad 4 | LECTURA, línea 4 |
| `invalido_instruccion.txt` | Instrucción `MOSTRAR:F01` | LECTURA, línea 3 |
| `invalido_encabezado.txt` | Encabezado incorrecto | LECTURA, línea 1 |
| `invalido_ref_inexistente.txt` | `REVELAR:F99` (la traza conserva la pista anterior) | PISTAS, línea 5, F04 |
| `invalido_ref_no_letra.txt` | `REVELAR:F01` donde F01 es ABRE | PISTAS, línea 6, F05 |
| `invalido_letra_repetida.txt` | Dos pistas revelan F01 | PISTAS, línea 5, F04 |

## Abrir en NetBeans / VS Code

- **NetBeans:** `File > New Project > Java with Ant > Java Project with Existing Sources`, carpeta del proyecto, y agregar `src` como *Source Package Folder*. En *Properties > Run*: Main Class `app.Main`, Arguments `datos/ejemplo_valido.txt`, Working Directory la carpeta del proyecto.
- **VS Code:** instalar *Extension Pack for Java*, abrir la carpeta que contiene `src` y `datos`, y usar los comandos de arriba en la terminal.
