#!/bin/bash
# Compila y ejecuta todos los archivos de datos/ con ambas versiones.
# Guarda cada salida en salidas/<nombre>.salida.txt y el resumen de CasosPrueba.
cd "$(dirname "$0")"
rm -rf out && mkdir -p out salidas
javac -encoding UTF-8 -d out $(find src -name "*.java") || exit 1
J="java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp out"
for f in datos/*.txt; do
  n=$(basename "$f" .txt)
  $J app.Main "$f" > "salidas/$n.salida.txt"
  echo "$n -> codigo de salida $?"
done
$J pruebas.CasosPrueba | tee salidas/casos_prueba.salida.txt
