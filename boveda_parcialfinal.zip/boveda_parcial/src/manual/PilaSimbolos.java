package manual;

/**
 * Pila propia (LIFO) de símbolos de apertura, con nodos enlazados.
 */
public final class PilaSimbolos {
    private Nodo<String> tope;

    public void apilar(String simbolo) {
        Nodo<String> nuevo = new Nodo<>(simbolo);
        nuevo.siguiente = tope;
        tope = nuevo;
    }

    /** Devuelve el símbolo del tope sin retirarlo. */
    public String consultar() {
        if (tope == null) {
            throw new IllegalStateException("La pila está vacía");
        }
        return tope.dato;
    }

    /** Retira y devuelve el símbolo del tope. */
    public String retirar() {
        if (tope == null) {
            throw new IllegalStateException("La pila está vacía");
        }
        String simbolo = tope.dato;
        tope = tope.siguiente;
        return simbolo;
    }

    public boolean estaVacia() {
        return tope == null;
    }
}
