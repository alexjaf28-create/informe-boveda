package manual;

import dominio.Ficha;
import dominio.TipoFicha;
import java.util.List;

/**
 * Versión con estructuras propias (ListaFichas, PilaSimbolos, ColaPistas).
 * Devuelve un informe de texto: la traza de eventos y, al final, una línea
 * "RESULTADO: <mensaje>" o "PRIMER ERROR: <detalle>".
 */
public final class ValidadorManual {

    public String ejecutar(List<Ficha> entrada) {
        StringBuilder traza = new StringBuilder();

        // Paso 2: transferir la entrada a la lista enlazada propia
        ListaFichas lista = cargarLista(entrada, traza);

        // Paso 3: validar anidamiento con la pila propia
        String error = validarDelimitadores(lista, traza);
        if (error != null) {
            return terminarConError(traza, error);
        }

        // Paso 4: encolar las pistas por prioridad
        ColaPistas<Ficha> colas = encolarPistas(lista, traza);

        // Paso 5: resolver las pistas y armar el mensaje
        StringBuilder mensaje = new StringBuilder();
        error = resolverPistas(lista, colas, mensaje, traza);
        if (error != null) {
            return terminarConError(traza, error);
        }
        evento(traza, "MENSAJE", "FINAL: " + mensaje);
        return traza + "RESULTADO: " + mensaje + "\n";
    }

    // ------------------------------------------------------------------ Paso 2
    private ListaFichas cargarLista(List<Ficha> entrada, StringBuilder traza) {
        ListaFichas lista = new ListaFichas();
        for (Ficha f : entrada) {
            lista.agregar(f);
            evento(traza, "LISTA", "INSERTAR " + f.getId() + " (posición " + f.getPosicion() + ")");
        }
        evento(traza, "LISTA", "RECORRIDO: " + lista.recorrido());
        return lista;
    }

    // ------------------------------------------------------------------ Paso 3
    /** Devuelve null si los delimitadores están bien anidados; si no, el primer error. */
    private String validarDelimitadores(ListaFichas lista, StringBuilder traza) {
        PilaSimbolos pila = new PilaSimbolos();

        for (Ficha f : lista) {
            if (f.getTipo() == TipoFicha.ABRE) {
                evento(traza, "PILA", "CONSULTAR " + f.getId() + " (línea " + f.getLinea()
                        + "): ABRE " + f.getValor());
                pila.apilar(f.getValor());
                evento(traza, "PILA", "APILAR " + f.getValor() + " de " + f.getId()
                        + "; tope: " + pila.consultar());

            } else if (f.getTipo() == TipoFicha.CIERRA) {
                evento(traza, "PILA", "CONSULTAR " + f.getId() + " (línea " + f.getLinea()
                        + "): CIERRA " + f.getValor());
                if (pila.estaVacia()) {
                    return error("PILA", f, "cierre " + f.getValor()
                            + " sin apertura: la pila está vacía");
                }
                String tope = pila.consultar();
                evento(traza, "PILA", "CONSULTAR TOPE: " + tope);
                String esperado = cierreDe(tope);
                if (!f.getValor().equals(esperado)) {
                    return error("PILA", f, "se esperaba " + esperado + " porque " + tope
                            + " está en el tope, pero se encontró " + f.getValor());
                }
                pila.retirar();
                evento(traza, "PILA", "RETIRAR " + tope + " con " + f.getId() + "; tope: "
                        + (pila.estaVacia() ? "pila vacía" : pila.consultar()));
            }
        }

        if (!pila.estaVacia()) {
            return "[PILA] fin de la lista: apertura sobrante, la pila no quedó vacía (tope: "
                    + pila.consultar() + ")";
        }
        evento(traza, "PILA", "FIN: la pila quedó vacía; delimitadores bien anidados");
        return null;
    }

    private static String cierreDe(String apertura) {
        switch (apertura) {
            case "(":
                return ")";
            case "[":
                return "]";
            default:
                return "}";
        }
    }

    // ------------------------------------------------------------------ Paso 4
    private ColaPistas<Ficha> encolarPistas(ListaFichas lista, StringBuilder traza) {
        ColaPistas<Ficha> colas = new ColaPistas<>();
        for (Ficha f : lista) {
            if (f.getTipo() == TipoFicha.PISTA) {
                int p = f.getPrioridad();
                colas.encolar(f, p);
                evento(traza, "COLA", "ENCOLAR " + f.getId() + " (" + f.getInstruccion() + ") en P" + p
                        + "; tamaño P" + p + "=" + colas.tamanio(p));
            }
        }
        evento(traza, "COLA", "ESTADO: P1=" + colas.tamanio(1) + " P2=" + colas.tamanio(2)
                + " P3=" + colas.tamanio(3));
        return colas;
    }

    // ------------------------------------------------------------------ Paso 5
    /** Devuelve null si todas las pistas se resolvieron; si no, el primer error. */
    private String resolverPistas(ListaFichas lista, ColaPistas<Ficha> colas,
                                  StringBuilder mensaje, StringBuilder traza) {
        ListaFichas reveladas = new ListaFichas();

        while (!colas.estaVacia()) {
            Ficha pista = colas.desencolar();
            int p = pista.getPrioridad();
            evento(traza, "COLA", "ATENDER P" + p + ": RETIRAR " + pista.getId() + " ("
                    + pista.getInstruccion() + "); tamaño P" + p + "=" + colas.tamanio(p));

            String[] partes = pista.getInstruccion().split(":", -1);
            String error = revelar(lista, reveladas, pista, partes[1], mensaje, traza);
            if (error != null) {
                return error;
            }

            if (partes[0].equals("ENCADENAR")) {
                // Pista generada REVELAR:id2, al final de la cola de la misma prioridad
                Ficha nueva = new Ficha("gen(" + pista.getId() + ")", TipoFicha.PISTA, "-", p,
                        "REVELAR:" + partes[2], pista.getPosicion(), pista.getLinea());
                colas.encolar(nueva, p);
                evento(traza, "COLA", "ENCOLAR " + nueva.getId() + " (" + nueva.getInstruccion()
                        + ") en P" + p + "; tamaño P" + p + "=" + colas.tamanio(p));
            }
        }
        return null;
    }

    /** Busca la letra en la lista, comprueba las reglas y la agrega al mensaje. */
    private String revelar(ListaFichas lista, ListaFichas reveladas, Ficha pista, String id,
                           StringBuilder mensaje, StringBuilder traza) {
        Ficha letra = lista.buscar(id);

        if (letra == null) {
            evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: no existe");
            return error("PISTAS", pista, pista.getInstruccion() + " hace referencia a " + id
                    + ", que no existe");
        }
        if (letra.getTipo() != TipoFicha.LETRA) {
            evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: es " + letra.getTipo());
            return error("PISTAS", pista, pista.getInstruccion() + " hace referencia a " + id
                    + ", que es " + letra.getTipo() + " y no LETRA");
        }
        if (reveladas.buscar(id) != null) {
            evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: LETRA " + letra.getValor()
                    + " ya revelada");
            return error("PISTAS", pista, pista.getInstruccion() + " intenta revelar " + id + " ("
                    + letra.getValor() + ") otra vez; cada letra se revela una sola vez");
        }
        evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: LETRA " + letra.getValor());
        reveladas.agregar(letra);
        mensaje.append(letra.getValor());
        evento(traza, "MENSAJE", "AGREGAR " + letra.getValor() + "; mensaje: " + mensaje);
        return null;
    }

    // ------------------------------------------------------------------ apoyo
    private static String error(String fase, Ficha f, String detalle) {
        return "[" + fase + "] línea " + f.getLinea() + ", ficha " + f.getId()
                + " (posición " + f.getPosicion() + "): " + detalle;
    }

    private static String terminarConError(StringBuilder traza, String error) {
        evento(traza, "ERROR", error);
        return traza + "PRIMER ERROR: " + error + "\n";
    }

    private static void evento(StringBuilder traza, String categoria, String texto) {
        traza.append('[').append(categoria).append("] ").append(texto).append('\n');
    }
}
