package manual;

import dominio.Ficha;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Lista enlazada simple propia, con referencia a la cabeza y a la cola.
 * Guarda las fichas en el orden del archivo. El recorrido se hace con for-each
 * (Iterable) sin exponer la clase Nodo.
 */
public final class ListaFichas implements Iterable<Ficha> {
    private Nodo<Ficha> cabeza;
    private Nodo<Ficha> cola;
    private int tamanio;

    /** Inserta la ficha al final de la lista. */
    public void agregar(Ficha ficha) {
        Nodo<Ficha> nuevo = new Nodo<>(ficha);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            cola.siguiente = nuevo;
        }
        cola = nuevo;
        tamanio++;
    }

    /** Busca una ficha por id recorriendo la lista desde la cabeza. Devuelve null si no existe. */
    public Ficha buscar(String id) {
        for (Nodo<Ficha> n = cabeza; n != null; n = n.siguiente) {
            if (n.dato.getId().equals(id)) {
                return n.dato;
            }
        }
        return null;
    }

    public int tamanio() {
        return tamanio;
    }

    /** Primera ficha de la lista, o null si está vacía. */
    public Ficha primera() {
        return cabeza == null ? null : cabeza.dato;
    }

    /** Recorrido en orden de archivo, por ejemplo: F01 -> F02 -> F03. */
    public String recorrido() {
        if (cabeza == null) {
            return "(lista vacía)";
        }
        StringBuilder sb = new StringBuilder();
        for (Nodo<Ficha> n = cabeza; n != null; n = n.siguiente) {
            if (n != cabeza) {
                sb.append(" -> ");
            }
            sb.append(n.dato.getId());
        }
        return sb.toString();
    }

    @Override
    public Iterator<Ficha> iterator() {
        return new Iterator<Ficha>() {
            private Nodo<Ficha> actual = cabeza;

            @Override
            public boolean hasNext() {
                return actual != null;
            }

            @Override
            public Ficha next() {
                if (actual == null) {
                    throw new NoSuchElementException();
                }
                Ficha dato = actual.dato;
                actual = actual.siguiente;
                return dato;
            }
        };
    }
}
