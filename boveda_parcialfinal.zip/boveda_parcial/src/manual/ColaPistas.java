package manual;

/**
 * Cola propia con tres prioridades. Internamente son tres colas FIFO enlazadas
 * (una por prioridad). desencolar() atiende primero la cola 1, luego la 2 y la 3;
 * dentro de cada una se respeta el orden de llegada.
 */
public final class ColaPistas<T> {

    /** Cola FIFO simple con referencias al frente y al final. */
    private static final class Fifo<E> {
        private Nodo<E> frente;
        private Nodo<E> ultimo;
        private int tamanio;

        void encolar(E dato) {
            Nodo<E> nuevo = new Nodo<>(dato);
            if (ultimo == null) {
                frente = nuevo;
            } else {
                ultimo.siguiente = nuevo;
            }
            ultimo = nuevo;
            tamanio++;
        }

        E desencolar() {
            E dato = frente.dato;
            frente = frente.siguiente;
            if (frente == null) {
                ultimo = null;
            }
            tamanio--;
            return dato;
        }

        boolean estaVacia() {
            return frente == null;
        }
    }

    private final Fifo<T> prioridad1 = new Fifo<>();
    private final Fifo<T> prioridad2 = new Fifo<>();
    private final Fifo<T> prioridad3 = new Fifo<>();

    private Fifo<T> cola(int prioridad) {
        switch (prioridad) {
            case 1:
                return prioridad1;
            case 2:
                return prioridad2;
            case 3:
                return prioridad3;
            default:
                throw new IllegalArgumentException("Prioridad fuera de 1-3: " + prioridad);
        }
    }

    /** Agrega la pista al final de la cola de su prioridad. */
    public void encolar(T pista, int prioridad) {
        cola(prioridad).encolar(pista);
    }

    /** Retira la pista del frente de la cola no vacía de menor número de prioridad. */
    public T desencolar() {
        if (!prioridad1.estaVacia()) {
            return prioridad1.desencolar();
        }
        if (!prioridad2.estaVacia()) {
            return prioridad2.desencolar();
        }
        if (!prioridad3.estaVacia()) {
            return prioridad3.desencolar();
        }
        throw new IllegalStateException("Las colas están vacías");
    }

    public boolean estaVacia() {
        return prioridad1.estaVacia() && prioridad2.estaVacia() && prioridad3.estaVacia();
    }

    /** Cantidad de pistas pendientes en la cola de esa prioridad (para la traza). */
    public int tamanio(int prioridad) {
        return cola(prioridad).tamanio;
    }
}
