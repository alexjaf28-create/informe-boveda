package pruebas;

import app.LectorFichas;
import biblioteca.ValidadorBiblioteca;
import dominio.Ficha;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import manual.ValidadorManual;

/**
 * Pruebas del laboratorio. Ejecuta cada archivo de datos/ con las dos versiones y comprueba
 * (1) que el resultado contenga lo esperado y (2) que los informes de ambas versiones sean idénticos.
 *
 * Uso: java -cp out pruebas.CasosPrueba [carpeta_de_datos]     (por defecto: datos)
 */
public final class CasosPrueba {

    private static String carpeta = "datos";
    private static int total = 0;
    private static int fallidas = 0;

    public static void main(String[] args) {
        if (args.length > 0) {
            carpeta = args[0];
        }

        System.out.println("--- Casos válidos ---");
        probar("ejemplo_valido.txt", "Ejemplo del enunciado (ENCADENAR)",
                "RESULTADO: SOL");
        probar("prueba_tres_prioridades.txt", "Pistas en P1, P2 y P3 con orden físico distinto",
                "RESULTADO: SOL");
        probar("prueba_fifo_misma_prioridad.txt", "Tres pistas de la misma prioridad (FIFO)",
                "RESULTADO: SOL");
        probar("prueba_encadenar_cola_con_pistas.txt", "ENCADENAR agrega trabajo a una cola con pistas",
                "RESULTADO: SOL");

        System.out.println("--- Errores de anidamiento ---");
        probar("invalido_f05_cierre_incorrecto.txt", "Cierre incorrecto de F05",
                "PRIMER ERROR: [PILA] línea 6, ficha F05 (posición 5): se esperaba ] porque [ está en el tope");
        probar("invalido_cierre_sin_apertura.txt", "Cierre sin apertura",
                "PRIMER ERROR: [PILA] línea 3, ficha F02 (posición 2): cierre ) sin apertura");
        probar("invalido_apertura_sobrante.txt", "Apertura sobrante",
                "PRIMER ERROR: [PILA] fin de la lista: apertura sobrante");

        System.out.println("--- Errores de formato ---");
        probar("invalido_id_repetido.txt", "ID repetido",
                "PRIMER ERROR: [LECTURA] línea 4, ficha F02 (posición 3): id repetido");
        probar("invalido_linea_incompleta.txt", "Línea incompleta",
                "PRIMER ERROR: [LECTURA] línea 4, ficha F03 (posición 3): línea incompleta");
        probar("invalido_tipo.txt", "Tipo inválido",
                "PRIMER ERROR: [LECTURA] línea 3, ficha F02 (posición 2): tipo 'NUMERO' inválido");
        probar("invalido_prioridad.txt", "Prioridad fuera de 1-3",
                "PRIMER ERROR: [LECTURA] línea 4, ficha F03 (posición 3): prioridad '4' inválida");
        probar("invalido_valor.txt", "Valor inválido para ABRE",
                "PRIMER ERROR: [LECTURA] línea 2, ficha F01 (posición 1): valor '<' inválido para ABRE");
        probar("invalido_instruccion.txt", "Instrucción de pista inválida",
                "PRIMER ERROR: [LECTURA] línea 3, ficha F02 (posición 2): instrucción 'MOSTRAR:F01' inválida");
        probar("invalido_encabezado.txt", "Encabezado incorrecto",
                "PRIMER ERROR: [LECTURA] línea 1: encabezado inválido");

        System.out.println("--- Errores de pistas ---");
        probar("invalido_ref_inexistente.txt", "Referencia inexistente",
                "PRIMER ERROR: [PISTAS] línea 5, ficha F04 (posición 4): REVELAR:F99 hace referencia a F99, que no existe");
        probar("invalido_ref_no_letra.txt", "Referencia a una ficha que no es LETRA",
                "PRIMER ERROR: [PISTAS] línea 6, ficha F05 (posición 5): REVELAR:F01 hace referencia a F01, que es ABRE");
        probar("invalido_letra_repetida.txt", "Letra revelada dos veces",
                "PRIMER ERROR: [PISTAS] línea 5, ficha F04 (posición 4): REVELAR:F01 intenta revelar F01");

        System.out.println();
        System.out.println("Pruebas: " + (total - fallidas) + " de " + total + " correctas.");
        System.exit(fallidas == 0 ? 0 : 1);
    }

    private static void probar(String archivo, String descripcion, String esperado) {
        total++;
        String manual;
        String biblioteca;
        try {
            List<Ficha> entrada = LectorFichas.leer(Paths.get(carpeta, archivo));
            manual = new ValidadorManual().ejecutar(entrada);
            biblioteca = new ValidadorBiblioteca().ejecutar(entrada);
        } catch (IllegalArgumentException e) {
            // Error de lectura: se detiene antes de cualquier validador (ambas versiones comparten lector)
            manual = "PRIMER ERROR: " + e.getMessage();
            biblioteca = manual;
        } catch (IOException e) {
            manual = "PRIMER ERROR: no se pudo leer " + archivo + " (" + e + ")";
            biblioteca = manual;
        }

        boolean esperadoOk = manual.contains(esperado);
        boolean equivalentes = manual.equals(biblioteca);
        boolean ok = esperadoOk && equivalentes;
        if (!ok) {
            fallidas++;
        }
        System.out.println((ok ? "[OK]    " : "[FALLA] ") + descripcion + "  (" + archivo + ")");
        if (!esperadoOk) {
            System.out.println("         esperado: " + esperado);
            System.out.println("         obtenido: " + manual.trim());
        }
        if (!equivalentes) {
            System.out.println("         las versiones manual y biblioteca NO coinciden");
        }
    }
}
