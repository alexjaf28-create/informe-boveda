package app;

import biblioteca.ValidadorBiblioteca;
import dominio.Ficha;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import manual.ValidadorManual;

/**
 * Punto de entrada.
 *
 * Uso: java -cp out app.Main <archivo.txt> [manual | biblioteca | ambas]
 * Sin segundo argumento ejecuta ambas versiones y las compara (paso 6).
 *
 * Código de salida: 0 = archivo válido, 1 = se encontró un error,
 * 2 = uso incorrecto, 3 = las dos versiones no coinciden.
 */
public final class Main {

    public static void main(String[] args) {
        if (args.length < 1 || args.length > 2) {
            System.out.println("Uso: java -cp out app.Main <archivo.txt> [manual | biblioteca | ambas]");
            System.exit(2);
            return;
        }
        Path ruta = Paths.get(args[0]);
        String modo = args.length == 2 ? args[1].toLowerCase() : "ambas";
        if (!modo.equals("manual") && !modo.equals("biblioteca") && !modo.equals("ambas")) {
            System.out.println("Modo desconocido: " + modo + " (use manual, biblioteca o ambas)");
            System.exit(2);
            return;
        }

        // Paso 1: lectura y validación del archivo
        System.out.println("================================================================");
        System.out.println("LECTURA  |  archivo: " + ruta);
        System.out.println("================================================================");
        List<Ficha> entrada;
        try {
            entrada = LectorFichas.leer(ruta);
        } catch (IllegalArgumentException e) {
            System.out.println("[ERROR] " + e.getMessage());
            System.out.println("PRIMER ERROR: " + e.getMessage());
            System.exit(1);
            return;
        } catch (IOException e) {
            String detalle = "[LECTURA] no se pudo leer el archivo " + ruta + " (" + e + ")";
            System.out.println("[ERROR] " + detalle);
            System.out.println("PRIMER ERROR: " + detalle);
            System.exit(1);
            return;
        }
        for (Ficha f : entrada) {
            System.out.println("[LECTURA] línea " + f.getLinea() + ", posición " + f.getPosicion() + ": "
                    + f.getId() + " " + f.getTipo() + " valor=" + f.getValor()
                    + " prioridad=" + f.getPrioridad() + " instruccion=" + f.getInstruccion());
        }
        System.out.println("[LECTURA] " + entrada.size() + " fichas leídas y validadas");
        System.out.println();

        // Pasos 2 a 5
        String informeManual = null;
        String informeBiblioteca = null;
        if (!modo.equals("biblioteca")) {
            informeManual = new ValidadorManual().ejecutar(entrada);
            System.out.println("================================================================");
            System.out.println("VERSIÓN MANUAL (estructuras propias)");
            System.out.println("================================================================");
            System.out.println(informeManual);
        }
        if (!modo.equals("manual")) {
            informeBiblioteca = new ValidadorBiblioteca().ejecutar(entrada);
            System.out.println("================================================================");
            System.out.println("VERSIÓN BIBLIOTECA (java.util)");
            System.out.println("================================================================");
            System.out.println(informeBiblioteca);
        }

        // Paso 6: comparación
        int codigo;
        if (informeManual != null && informeBiblioteca != null) {
            boolean iguales = comparar(informeManual, informeBiblioteca);
            codigo = !iguales ? 3 : (esValido(informeManual) ? 0 : 1);
        } else {
            String informe = informeManual != null ? informeManual : informeBiblioteca;
            codigo = esValido(informe) ? 0 : 1;
        }
        System.exit(codigo);
    }

    /** La última línea del informe es RESULTADO: ... o PRIMER ERROR: ... */
    private static String ultimaLinea(String informe) {
        String sinFin = informe.endsWith("\n") ? informe.substring(0, informe.length() - 1) : informe;
        return sinFin.substring(sinFin.lastIndexOf('\n') + 1);
    }

    private static boolean esValido(String informe) {
        return ultimaLinea(informe).startsWith("RESULTADO:");
    }

    /** Compara mensaje o primer error, y el orden de los eventos de la traza. */
    private static boolean comparar(String manual, String biblioteca) {
        System.out.println("================================================================");
        System.out.println("COMPARACIÓN MANUAL vs BIBLIOTECA");
        System.out.println("================================================================");

        String finalManual = ultimaLinea(manual);
        String finalBiblioteca = ultimaLinea(biblioteca);
        boolean mismoFinal = finalManual.equals(finalBiblioteca);
        System.out.println("Mensaje / primer error: " + (mismoFinal ? "IGUAL" : "DIFERENTE"));
        System.out.println("   manual     = " + finalManual);
        System.out.println("   biblioteca = " + finalBiblioteca);

        String[] em = manual.split("\n");
        String[] eb = biblioteca.split("\n");
        int limite = Math.min(em.length, eb.length);
        int diferente = -1;
        for (int i = 0; i < limite; i++) {
            if (!em[i].equals(eb[i])) {
                diferente = i;
                break;
            }
        }
        if (diferente < 0 && em.length != eb.length) {
            diferente = limite;
        }
        boolean mismaTraza = diferente < 0;
        System.out.println("Orden de eventos: manual=" + em.length + " líneas | biblioteca=" + eb.length
                + " líneas -> " + (mismaTraza ? "IGUAL" : "DIFERENTE"));
        if (!mismaTraza) {
            System.out.println("   primera diferencia en la línea " + (diferente + 1));
        }

        boolean todo = mismoFinal && mismaTraza;
        System.out.println("CONCLUSIÓN: " + (todo ? "las dos versiones son equivalentes."
                : "las dos versiones NO coinciden."));
        return todo;
    }
}
