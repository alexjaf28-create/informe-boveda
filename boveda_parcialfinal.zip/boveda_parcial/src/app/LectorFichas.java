package app;

import dominio.Ficha;
import dominio.TipoFicha;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Paso 1: lee el archivo UTF-8 y valida encabezado, cinco campos por fila, tipo,
 * valor, prioridad, instrucción, identificadores únicos y sintaxis de las referencias.
 * Se detiene en el primer error: lanza IllegalArgumentException con el mensaje
 * "[LECTURA] línea N, ficha ID (posición P): detalle".
 * Los problemas de acceso al archivo se propagan como IOException.
 */
public final class LectorFichas {

    public static final String ENCABEZADO = "id|tipo|valor|prioridad|instruccion";

    private LectorFichas() {}

    public static List<Ficha> leer(Path ruta) throws IOException {
        List<String> lineas = Files.readAllLines(ruta, StandardCharsets.UTF_8);

        if (lineas.isEmpty()) {
            throw new IllegalArgumentException(
                    "[LECTURA] línea 1: el archivo está vacío; falta el encabezado");
        }
        String primera = lineas.get(0);
        if (primera.startsWith("﻿")) {
            primera = primera.substring(1); // quita la marca BOM de UTF-8 si existe
        }
        if (!ENCABEZADO.equals(primera.trim())) {
            throw new IllegalArgumentException(
                    "[LECTURA] línea 1: encabezado inválido; se esperaba " + ENCABEZADO);
        }

        List<Ficha> fichas = new ArrayList<>();
        Map<String, Integer> lineaDeId = new HashMap<>();
        for (int i = 1; i < lineas.size(); i++) {
            int linea = i + 1;     // línea física: el encabezado es la línea 1
            int posicion = i;      // número de ficha leído, empezando en 1
            fichas.add(leerFila(lineas.get(i), posicion, linea, lineaDeId));
        }
        return fichas;
    }

    private static Ficha leerFila(String texto, int posicion, int linea,
                                  Map<String, Integer> lineaDeId) {
        String[] campos = texto.split("\\|", -1);
        String idParaError = campos[0].trim().isEmpty() ? null : campos[0].trim();

        if (campos.length != 5) {
            throw error(linea, idParaError, posicion,
                    "línea incompleta o con campos de más: se esperaban 5 campos y hay " + campos.length);
        }
        String id = campos[0].trim();
        String tipoTexto = campos[1].trim();
        String valor = campos[2].trim();
        String prioridadTexto = campos[3].trim();
        String instruccion = campos[4].trim();

        // id
        if (!idValido(id)) {
            throw error(linea, idParaError, posicion,
                    "id vacío o con caracteres no permitidos (espacios, ':' o '|')");
        }
        if (lineaDeId.containsKey(id)) {
            throw error(linea, id, posicion, "id repetido; ya se usó en la línea " + lineaDeId.get(id));
        }

        // tipo
        TipoFicha tipo = tipoDe(tipoTexto);
        if (tipo == null) {
            throw error(linea, id, posicion,
                    "tipo '" + tipoTexto + "' inválido; debe ser ABRE, CIERRA, LETRA o PISTA");
        }

        // valor
        switch (tipo) {
            case ABRE:
                if (!(valor.equals("(") || valor.equals("[") || valor.equals("{"))) {
                    throw error(linea, id, posicion,
                            "valor '" + valor + "' inválido para ABRE; debe ser ( [ o {");
                }
                break;
            case CIERRA:
                if (!(valor.equals(")") || valor.equals("]") || valor.equals("}"))) {
                    throw error(linea, id, posicion,
                            "valor '" + valor + "' inválido para CIERRA; debe ser ) ] o }");
                }
                break;
            case LETRA:
                if (valor.length() != 1 || !Character.isLetter(valor.charAt(0))) {
                    throw error(linea, id, posicion,
                            "valor '" + valor + "' inválido para LETRA; debe ser una sola letra");
                }
                break;
            default: // PISTA
                if (!valor.equals("-")) {
                    throw error(linea, id, posicion,
                            "valor '" + valor + "' inválido para PISTA; debe ser -");
                }
                break;
        }

        // prioridad
        int prioridad;
        if (prioridadTexto.equals("1")) {
            prioridad = 1;
        } else if (prioridadTexto.equals("2")) {
            prioridad = 2;
        } else if (prioridadTexto.equals("3")) {
            prioridad = 3;
        } else {
            throw error(linea, id, posicion,
                    "prioridad '" + prioridadTexto + "' inválida; debe ser 1, 2 o 3");
        }

        // instrucción
        if (tipo == TipoFicha.PISTA) {
            if (!instruccionValida(instruccion)) {
                throw error(linea, id, posicion, "instrucción '" + instruccion
                        + "' inválida; debe ser REVELAR:id o ENCADENAR:id1:id2");
            }
        } else if (!instruccion.equals("-")) {
            throw error(linea, id, posicion,
                    "instrucción '" + instruccion + "' inválida para " + tipo + "; debe ser -");
        }

        lineaDeId.put(id, linea);
        return new Ficha(id, tipo, valor, prioridad, instruccion, posicion, linea);
    }

    private static TipoFicha tipoDe(String texto) {
        for (TipoFicha t : TipoFicha.values()) {
            if (t.name().equals(texto)) {
                return t;
            }
        }
        return null;
    }

    /** REVELAR:id o ENCADENAR:id1:id2, con ids no vacíos. */
    private static boolean instruccionValida(String instruccion) {
        String[] partes = instruccion.split(":", -1);
        if (partes.length == 2) {
            return partes[0].equals("REVELAR") && idValido(partes[1]);
        }
        if (partes.length == 3) {
            return partes[0].equals("ENCADENAR") && idValido(partes[1]) && idValido(partes[2]);
        }
        return false;
    }

    /** Un id es válido si no está vacío y no tiene espacios, ':' ni '|'. */
    private static boolean idValido(String id) {
        if (id.isEmpty()) {
            return false;
        }
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            if (Character.isWhitespace(c) || c == ':' || c == '|') {
                return false;
            }
        }
        return true;
    }

    private static IllegalArgumentException error(int linea, String id, int posicion, String detalle) {
        String ficha = id == null ? "" : ", ficha " + id + " (posición " + posicion + ")";
        return new IllegalArgumentException("[LECTURA] línea " + linea + ficha + ": " + detalle);
    }
}
