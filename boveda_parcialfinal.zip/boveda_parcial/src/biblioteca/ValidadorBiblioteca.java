package biblioteca;

import dominio.Ficha;
import dominio.TipoFicha;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.StringJoiner;

/**
 * Misma lógica que ValidadorManual, usando estructuras de java.util:
 * LinkedList (lista), ArrayDeque como Deque (pila) y tres Queue (colas por prioridad).
 * Devuelve el mismo formato de informe.
 */
public final class ValidadorBiblioteca {

    public String ejecutar(List<Ficha> entrada) {
        StringBuilder traza = new StringBuilder();

        // Paso 2: pasar la entrada a una LinkedList
        LinkedList<Ficha> lista = cargarLista(entrada, traza);

        // Paso 3: validar anidamiento con la pila
        String error = validarDelimitadores(lista, traza);
        if (error != null) {
            return terminarConError(traza, error);
        }

        // Paso 4: encolar las pistas por prioridad
        List<Queue<Ficha>> colas = encolarPistas(lista, traza);

        // Paso 5: resolver las pistas y armar el mensaje
        StringBuilder mensaje = new StringBuilder();
        error = resolverPistas(lista, colas, mensaje, traza);
        if (error != null) {
            return terminarConError(traza, error);
        }
        evento(traza, "MENSAJE", "FINAL: " + mensaje);
        return traza + "RESULTADO: " + mensaje + "\n";
    }

    // ------------------------------------------------------------------ Paso 2
    private LinkedList<Ficha> cargarLista(List<Ficha> entrada, StringBuilder traza) {
        LinkedList<Ficha> lista = new LinkedList<>();
        for (Ficha f : entrada) {
            lista.addLast(f);
            evento(traza, "LISTA", "INSERTAR " + f.getId() + " (posición " + f.getPosicion() + ")");
        }
        StringJoiner recorrido = new StringJoiner(" -> ");
        for (Ficha f : lista) {
            recorrido.add(f.getId());
        }
        evento(traza, "LISTA", "RECORRIDO: " + (lista.isEmpty() ? "(lista vacía)" : recorrido));
        return lista;
    }

    // ------------------------------------------------------------------ Paso 3
    /** Devuelve null si los delimitadores están bien anidados; si no, el primer error. */
    private String validarDelimitadores(LinkedList<Ficha> lista, StringBuilder traza) {
        Deque<String> pila = new ArrayDeque<>();

        for (Ficha f : lista) {
            if (f.getTipo() == TipoFicha.ABRE) {
                evento(traza, "PILA", "CONSULTAR " + f.getId() + " (línea " + f.getLinea()
                        + "): ABRE " + f.getValor());
                pila.push(f.getValor());
                evento(traza, "PILA", "APILAR " + f.getValor() + " de " + f.getId()
                        + "; tope: " + pila.peek());

            } else if (f.getTipo() == TipoFicha.CIERRA) {
                evento(traza, "PILA", "CONSULTAR " + f.getId() + " (línea " + f.getLinea()
                        + "): CIERRA " + f.getValor());
                if (pila.isEmpty()) {
                    return error("PILA", f, "cierre " + f.getValor()
                            + " sin apertura: la pila está vacía");
                }
                String tope = pila.peek();
                evento(traza, "PILA", "CONSULTAR TOPE: " + tope);
                String esperado = cierreDe(tope);
                if (!f.getValor().equals(esperado)) {
                    return error("PILA", f, "se esperaba " + esperado + " porque " + tope
                            + " está en el tope, pero se encontró " + f.getValor());
                }
                pila.pop();
                evento(traza, "PILA", "RETIRAR " + tope + " con " + f.getId() + "; tope: "
                        + (pila.isEmpty() ? "pila vacía" : pila.peek()));
            }
        }

        if (!pila.isEmpty()) {
            return "[PILA] fin de la lista: apertura sobrante, la pila no quedó vacía (tope: "
                    + pila.peek() + ")";
        }
        evento(traza, "PILA", "FIN: la pila quedó vacía; delimitadores bien anidados");
        return null;
    }

    private static String cierreDe(String apertura) {
        switch (apertura) {
            case "(":
                return ")";
            case "[":
                return "]";
            default:
                return "}";
        }
    }

    // ------------------------------------------------------------------ Paso 4
    private List<Queue<Ficha>> encolarPistas(LinkedList<Ficha> lista, StringBuilder traza) {
        List<Queue<Ficha>> colas = new ArrayList<>();
        colas.add(new LinkedList<Ficha>());
        colas.add(new LinkedList<Ficha>());
        colas.add(new LinkedList<Ficha>());

        for (Ficha f : lista) {
            if (f.getTipo() == TipoFicha.PISTA) {
                int p = f.getPrioridad();
                Queue<Ficha> cola = colas.get(p - 1);
                cola.offer(f);
                evento(traza, "COLA", "ENCOLAR " + f.getId() + " (" + f.getInstruccion() + ") en P" + p
                        + "; tamaño P" + p + "=" + cola.size());
            }
        }
        evento(traza, "COLA", "ESTADO: P1=" + colas.get(0).size() + " P2=" + colas.get(1).size()
                + " P3=" + colas.get(2).size());
        return colas;
    }

    // ------------------------------------------------------------------ Paso 5
    /** Devuelve null si todas las pistas se resolvieron; si no, el primer error. */
    private String resolverPistas(LinkedList<Ficha> lista, List<Queue<Ficha>> colas,
                                  StringBuilder mensaje, StringBuilder traza) {
        Set<String> reveladas = new HashSet<>();

        // Se atiende la cola 1, luego la 2 y la 3; cada una en orden FIFO.
        for (int p = 1; p <= 3; p++) {
            Queue<Ficha> cola = colas.get(p - 1);
            while (!cola.isEmpty()) {
                Ficha pista = cola.poll();
                evento(traza, "COLA", "ATENDER P" + p + ": RETIRAR " + pista.getId() + " ("
                        + pista.getInstruccion() + "); tamaño P" + p + "=" + cola.size());

                String[] partes = pista.getInstruccion().split(":", -1);
                String error = revelar(lista, reveladas, pista, partes[1], mensaje, traza);
                if (error != null) {
                    return error;
                }

                if (partes[0].equals("ENCADENAR")) {
                    // Pista generada REVELAR:id2, al final de la cola de la misma prioridad
                    Ficha nueva = new Ficha("gen(" + pista.getId() + ")", TipoFicha.PISTA, "-", p,
                            "REVELAR:" + partes[2], pista.getPosicion(), pista.getLinea());
                    cola.offer(nueva);
                    evento(traza, "COLA", "ENCOLAR " + nueva.getId() + " (" + nueva.getInstruccion()
                            + ") en P" + p + "; tamaño P" + p + "=" + cola.size());
                }
            }
        }
        return null;
    }

    /** Busca la letra recorriendo la lista, comprueba las reglas y la agrega al mensaje. */
    private String revelar(LinkedList<Ficha> lista, Set<String> reveladas, Ficha pista, String id,
                           StringBuilder mensaje, StringBuilder traza) {
        Ficha letra = null;
        for (Ficha f : lista) {
            if (f.getId().equals(id)) {
                letra = f;
                break;
            }
        }

        if (letra == null) {
            evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: no existe");
            return error("PISTAS", pista, pista.getInstruccion() + " hace referencia a " + id
                    + ", que no existe");
        }
        if (letra.getTipo() != TipoFicha.LETRA) {
            evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: es " + letra.getTipo());
            return error("PISTAS", pista, pista.getInstruccion() + " hace referencia a " + id
                    + ", que es " + letra.getTipo() + " y no LETRA");
        }
        if (reveladas.contains(id)) {
            evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: LETRA " + letra.getValor()
                    + " ya revelada");
            return error("PISTAS", pista, pista.getInstruccion() + " intenta revelar " + id + " ("
                    + letra.getValor() + ") otra vez; cada letra se revela una sola vez");
        }
        evento(traza, "BUSQUEDA", "BUSCAR " + id + " en la lista: LETRA " + letra.getValor());
        reveladas.add(id);
        mensaje.append(letra.getValor());
        evento(traza, "MENSAJE", "AGREGAR " + letra.getValor() + "; mensaje: " + mensaje);
        return null;
    }

    // ------------------------------------------------------------------ apoyo
    private static String error(String fase, Ficha f, String detalle) {
        return "[" + fase + "] línea " + f.getLinea() + ", ficha " + f.getId()
                + " (posición " + f.getPosicion() + "): " + detalle;
    }

    private static String terminarConError(StringBuilder traza, String error) {
        evento(traza, "ERROR", error);
        return traza + "PRIMER ERROR: " + error + "\n";
    }

    private static void evento(StringBuilder traza, String categoria, String texto) {
        traza.append('[').append(categoria).append("] ").append(texto).append('\n');
    }
}
